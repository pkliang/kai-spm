#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class NSString, NSSet<ObjectType>, NSObject, NSNumber, NSMutableSet<ObjectType>, NSMutableDictionary<KeyType, ObjectType>, NSMutableArray<ObjectType>, NSError, NSDictionary<KeyType, ObjectType>, NSArray<ObjectType>, KAI__SkieTypeExportsKt, KAI__SkieSuspendWrappersKt, KAIWeltGoService, KAIUserCompanion, KAIUser, KAIUShort, KAIULong, KAIUInt, KAIUByte, KAISuggestionResponseCompanion, KAISuggestionResponse, KAISuggestionRepositoryWeltGoImpl, KAISuggestion, KAISource, KAISkie_SuspendResultSuccess, KAISkie_SuspendResultError, KAISkie_SuspendResultCanceled, KAISkie_SuspendResult, KAISkie_SuspendHandler, KAISkie_CancellationHandler, KAISkieKotlinStateFlow<T>, KAISkieKotlinSharedFlow<T>, KAISkieKotlinOptionalStateFlow<T>, KAISkieKotlinOptionalSharedFlow<T>, KAISkieKotlinOptionalMutableStateFlow<T>, KAISkieKotlinOptionalMutableSharedFlow<T>, KAISkieKotlinOptionalFlow<T>, KAISkieKotlinMutableStateFlow<T>, KAISkieKotlinMutableSharedFlow<T>, KAISkieKotlinFlow<T>, KAISkieColdFlowIterator<E>, KAIShort, KAIServerSentEventDataResponseCompanion, KAIServerSentEventDataResponse, KAIQuestion, KAIPromptRepositoryWeltGoImpl, KAIPrompt, KAIPlatform_iosKt, KAINumber, KAIMutableSet<ObjectType>, KAIMutableDictionary<KeyType, ObjectType>, KAILong, KAIKtor_sseServerSentEvent, KAIKotlinx_serialization_coreStructureKindOBJECT, KAIKotlinx_serialization_coreStructureKindMAP, KAIKotlinx_serialization_coreStructureKindLIST, KAIKotlinx_serialization_coreStructureKindCLASS, KAIKotlinx_serialization_coreStructureKind, KAIKotlinx_serialization_coreSerializersModule, KAIKotlinx_serialization_coreSerialKindENUM, KAIKotlinx_serialization_coreSerialKindCONTEXTUAL, KAIKotlinx_serialization_coreSerialKind, KAIKotlinx_serialization_corePrimitiveKindSTRING, KAIKotlinx_serialization_corePrimitiveKindSHORT, KAIKotlinx_serialization_corePrimitiveKindLONG, KAIKotlinx_serialization_corePrimitiveKindINT, KAIKotlinx_serialization_corePrimitiveKindFLOAT, KAIKotlinx_serialization_corePrimitiveKindDOUBLE, KAIKotlinx_serialization_corePrimitiveKindCHAR, KAIKotlinx_serialization_corePrimitiveKindBYTE, KAIKotlinx_serialization_corePrimitiveKindBOOLEAN, KAIKotlinx_serialization_corePrimitiveKind, KAIKotlinx_serialization_corePolymorphicKindSEALED, KAIKotlinx_serialization_corePolymorphicKindOPEN, KAIKotlinx_serialization_corePolymorphicKind, KAIKotlinThrowable, KAIKotlinRuntimeException, KAIKotlinNothing, KAIKotlinIllegalStateException, KAIKotlinException, KAIKotlinEnumCompanion, KAIKotlinEnum<E>, KAIKotlinCancellationException, KAIKotlinArray<T>, KAIInt, KAIGetSuggestionsUseCase, KAIGetPromptsUseCase, KAIGetPromptUseCase, KAIFloat, KAIFeaturedPromptsResponseCompanion, KAIFeaturedPromptsResponse, KAIFeaturedPromptCompanion, KAIFeaturedPrompt, KAIDouble, KAIDeltaCompanion, KAIDelta, KAICreateConversationUseCase, KAIConversationResponseCompanion, KAIConversationResponse, KAIConversationRepositoryWeltGoImpl, KAIConversation, KAIChoiceResponseCompanion, KAIChoiceResponse, KAIChoiceCompanion, KAIChoice, KAIChatUseCase, KAIChatResponseCompanion, KAIChatResponse, KAIChatRequestCompanion, KAIChatRequest, KAIChatRepositoryWeltGoImpl, KAIChatFlowUseCase, KAIChat, KAIByte, KAIBoolean, KAIBase, KAIApiConstants, KAIAnswer;

@protocol NSCopying, KAISuggestionRepository, KAISkie_DispatcherDelegate, KAIPromptRepository, KAIKotlinx_serialization_coreSerializersModuleCollector, KAIKotlinx_serialization_coreSerializationStrategy, KAIKotlinx_serialization_coreSerialDescriptor, KAIKotlinx_serialization_coreKSerializer, KAIKotlinx_serialization_coreEncoder, KAIKotlinx_serialization_coreDeserializationStrategy, KAIKotlinx_serialization_coreDecoder, KAIKotlinx_serialization_coreCompositeEncoder, KAIKotlinx_serialization_coreCompositeDecoder, KAIKotlinx_coroutines_coreStateFlow, KAIKotlinx_coroutines_coreSharedFlow, KAIKotlinx_coroutines_coreRunnable, KAIKotlinx_coroutines_coreMutableStateFlow, KAIKotlinx_coroutines_coreMutableSharedFlow, KAIKotlinx_coroutines_coreFlowCollector, KAIKotlinx_coroutines_coreFlow, KAIKotlinKDeclarationContainer, KAIKotlinKClassifier, KAIKotlinKClass, KAIKotlinKAnnotatedElement, KAIKotlinIterator, KAIKotlinComparable, KAIKotlinAnnotation, KAIConversationRepository, KAIChatRepository, KAIBaseUseCaseWithParams, KAIBaseUseCaseFlow, KAIBaseUseCase;

// Due to an Obj-C/Swift interop limitation, SKIE cannot generate Swift types with a lambda type argument.
// Example of such type is: A<() -> Unit> where A<T> is a generic class.
// To avoid compilation errors SKIE replaces these type arguments with __SkieLambdaErrorType, resulting in A<__SkieLambdaErrorType>.
// Generated declarations that reference __SkieLambdaErrorType cannot be called in any way and the __SkieLambdaErrorType class cannot be used.
// The original declarations can still be used in the same way as other declarations hidden by SKIE (and with the same limitations as without SKIE).
@interface __SkieLambdaErrorType : NSObject
- (instancetype _Nonnull)init __attribute__((unavailable));
+ (instancetype _Nonnull)new __attribute__((unavailable));
@end

// Due to an Obj-C/Swift interop limitation, SKIE cannot generate Swift code that uses external Obj-C types for which SKIE doesn't know a fully qualified name.
// This problem occurs when custom Cinterop bindings are used because those do not contain the name of the Framework that provides implementation for those binding.
// The name can be configured manually using the SKIE Gradle configuration key 'ClassInterop.CInteropFrameworkName' in the same way as other SKIE features.
// To avoid compilation errors SKIE replaces types with unknown Framework name with __SkieUnknownCInteropFrameworkErrorType.
// Generated declarations that reference __SkieUnknownCInteropFrameworkErrorType cannot be called in any way and the __SkieUnknownCInteropFrameworkErrorType class cannot be used.
@interface __SkieUnknownCInteropFrameworkErrorType : NSObject
- (instancetype _Nonnull)init __attribute__((unavailable));
+ (instancetype _Nonnull)new __attribute__((unavailable));
@end

typedef id<KAIPromptRepository> _Nonnull Skie__TypeDef__0__id_KAIPromptRepository_ __attribute__((__swift_private__));

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface KAIBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface KAIBase (KAIBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface KAIMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface KAIMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorKAIKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface KAINumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface KAIByte : KAINumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface KAIUByte : KAINumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface KAIShort : KAINumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface KAIUShort : KAINumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface KAIInt : KAINumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface KAIUInt : KAINumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface KAILong : KAINumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface KAIULong : KAINumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface KAIFloat : KAINumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface KAIDouble : KAINumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface KAIBoolean : KAINumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieColdFlowIterator")))
@interface KAISkieColdFlowIterator<E> : KAIBase
- (instancetype)initWithFlow:(id<KAIKotlinx_coroutines_coreFlow>)flow __attribute__((swift_name("init(flow:)"))) __attribute__((objc_designated_initializer));
- (void)cancel __attribute__((swift_name("cancel()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)hasNextWithCompletionHandler:(void (^)(KAIBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("hasNext(completionHandler:)")));
- (E _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol KAIKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinFlow")))
@interface KAISkieKotlinFlow<__covariant T> : KAIBase <KAIKotlinx_coroutines_coreFlow>
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSharedFlow")))
@protocol KAIKotlinx_coroutines_coreSharedFlow <KAIKotlinx_coroutines_coreFlow>
@required
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol KAIKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreMutableSharedFlow")))
@protocol KAIKotlinx_coroutines_coreMutableSharedFlow <KAIKotlinx_coroutines_coreSharedFlow, KAIKotlinx_coroutines_coreFlowCollector>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(id _Nullable)value __attribute__((swift_name("tryEmit(value:)")));
@property (readonly) id<KAIKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinMutableSharedFlow")))
@interface KAISkieKotlinMutableSharedFlow<T> : KAIBase <KAIKotlinx_coroutines_coreMutableSharedFlow>
@property (readonly) NSArray<T> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) id<KAIKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreMutableSharedFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(T)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(T)value __attribute__((swift_name("tryEmit(value:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreStateFlow")))
@protocol KAIKotlinx_coroutines_coreStateFlow <KAIKotlinx_coroutines_coreSharedFlow>
@required
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreMutableStateFlow")))
@protocol KAIKotlinx_coroutines_coreMutableStateFlow <KAIKotlinx_coroutines_coreStateFlow, KAIKotlinx_coroutines_coreMutableSharedFlow>
@required
- (void)setValue:(id _Nullable)value __attribute__((swift_name("setValue(_:)")));
- (BOOL)compareAndSetExpect:(id _Nullable)expect update:(id _Nullable)update __attribute__((swift_name("compareAndSet(expect:update:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinMutableStateFlow")))
@interface KAISkieKotlinMutableStateFlow<T> : KAIBase <KAIKotlinx_coroutines_coreMutableStateFlow>
@property (readonly) NSArray<T> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) id<KAIKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
@property T value __attribute__((swift_name("value")));
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreMutableStateFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
- (BOOL)compareAndSetExpect:(T)expect update:(T)update __attribute__((swift_name("compareAndSet(expect:update:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(T)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(T)value __attribute__((swift_name("tryEmit(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalFlow")))
@interface KAISkieKotlinOptionalFlow<__covariant T> : KAIBase <KAIKotlinx_coroutines_coreFlow>
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalMutableSharedFlow")))
@interface KAISkieKotlinOptionalMutableSharedFlow<T> : KAIBase <KAIKotlinx_coroutines_coreMutableSharedFlow>
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) id<KAIKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreMutableSharedFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(T _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(T _Nullable)value __attribute__((swift_name("tryEmit(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalMutableStateFlow")))
@interface KAISkieKotlinOptionalMutableStateFlow<T> : KAIBase <KAIKotlinx_coroutines_coreMutableStateFlow>
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) id<KAIKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
@property T _Nullable value __attribute__((swift_name("value")));
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreMutableStateFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
- (BOOL)compareAndSetExpect:(T _Nullable)expect update:(T _Nullable)update __attribute__((swift_name("compareAndSet(expect:update:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(T _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(T _Nullable)value __attribute__((swift_name("tryEmit(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalSharedFlow")))
@interface KAISkieKotlinOptionalSharedFlow<__covariant T> : KAIBase <KAIKotlinx_coroutines_coreSharedFlow>
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreSharedFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalStateFlow")))
@interface KAISkieKotlinOptionalStateFlow<__covariant T> : KAIBase <KAIKotlinx_coroutines_coreStateFlow>
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreStateFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinSharedFlow")))
@interface KAISkieKotlinSharedFlow<__covariant T> : KAIBase <KAIKotlinx_coroutines_coreSharedFlow>
@property (readonly) NSArray<T> *replayCache __attribute__((swift_name("replayCache")));
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreSharedFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinStateFlow")))
@interface KAISkieKotlinStateFlow<__covariant T> : KAIBase <KAIKotlinx_coroutines_coreStateFlow>
@property (readonly) NSArray<T> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) T value __attribute__((swift_name("value")));
- (instancetype)initWithDelegate:(id<KAIKotlinx_coroutines_coreStateFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_CancellationHandler")))
@interface KAISkie_CancellationHandler : KAIBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)cancel __attribute__((swift_name("cancel()")));
@end

__attribute__((swift_name("Skie_DispatcherDelegate")))
@protocol KAISkie_DispatcherDelegate
@required
- (void)dispatchBlock:(id<KAIKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_SuspendHandler")))
@interface KAISkie_SuspendHandler : KAIBase
- (instancetype)initWithCancellationHandler:(KAISkie_CancellationHandler *)cancellationHandler dispatcherDelegate:(id<KAISkie_DispatcherDelegate>)dispatcherDelegate onResult:(void (^)(KAISkie_SuspendResult *))onResult __attribute__((swift_name("init(cancellationHandler:dispatcherDelegate:onResult:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Skie_SuspendResult")))
@interface KAISkie_SuspendResult : KAIBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_SuspendResult.Canceled")))
@interface KAISkie_SuspendResultCanceled : KAISkie_SuspendResult
@property (class, readonly, getter=shared) KAISkie_SuspendResultCanceled *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)canceled __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_SuspendResult.Error")))
@interface KAISkie_SuspendResultError : KAISkie_SuspendResult
@property (readonly) NSError *error __attribute__((swift_name("error")));
- (instancetype)initWithError:(NSError *)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (KAISkie_SuspendResultError *)doCopyError:(NSError *)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_SuspendResult.Success")))
@interface KAISkie_SuspendResultSuccess : KAISkie_SuspendResult
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
- (instancetype)initWithValue:(id _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (KAISkie_SuspendResultSuccess *)doCopyValue:(id _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiConstants")))
@interface KAIApiConstants : KAIBase
@property (class, readonly, getter=shared) KAIApiConstants *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *BASE_URL __attribute__((swift_name("BASE_URL")));
@property (readonly) NSString *CONVERSATION_ID_HEADER __attribute__((swift_name("CONVERSATION_ID_HEADER")));
@property (readonly) NSString *CONVERSATION_LENGTH_HEADER __attribute__((swift_name("CONVERSATION_LENGTH_HEADER")));
@property (readonly) NSString *DEFAULT_EXPERIENCE_ID __attribute__((swift_name("DEFAULT_EXPERIENCE_ID")));
@property (readonly) NSString *EXPERIENCE_ID_HEADER __attribute__((swift_name("EXPERIENCE_ID_HEADER")));
@property (readonly) NSString *MESSAGE_ID_HEADER __attribute__((swift_name("MESSAGE_ID_HEADER")));
@property (readonly) NSString *USER_ID_HEADER __attribute__((swift_name("USER_ID_HEADER")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)apiConstants __attribute__((swift_name("init()")));
@end

__attribute__((swift_name("ChatRepository")))
@protocol KAIChatRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)chatQuestion:(KAIQuestion *)question completionHandler:(void (^)(KAIAnswer * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("chat(question:completionHandler:)")));
- (id<KAIKotlinx_coroutines_coreFlow>)chatFlowQuestion:(KAIQuestion *)question __attribute__((swift_name("chatFlow(question:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRepositoryWeltGoImpl")))
@interface KAIChatRepositoryWeltGoImpl : KAIBase <KAIChatRepository>
- (instancetype)initWithWeltGoService:(KAIWeltGoService *)weltGoService __attribute__((swift_name("init(weltGoService:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)chatQuestion:(KAIQuestion *)question completionHandler:(void (^)(KAIAnswer * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("chat(question:completionHandler:)")));
- (id<KAIKotlinx_coroutines_coreFlow>)chatFlowQuestion:(KAIQuestion *)question __attribute__((swift_name("chatFlow(question:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRequest")))
@interface KAIChatRequest : KAIBase
@property (class, readonly, getter=companion) KAIChatRequestCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *source __attribute__((swift_name("source")));
- (instancetype)initWithMessage:(NSString *)message source:(NSString *)source __attribute__((swift_name("init(message:source:)"))) __attribute__((objc_designated_initializer));
- (KAIChatRequest *)doCopyMessage:(NSString *)message source:(NSString *)source __attribute__((swift_name("doCopy(message:source:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRequest.Companion")))
@interface KAIChatRequestCompanion : KAIBase
@property (class, readonly, getter=shared) KAIChatRequestCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatResponse")))
@interface KAIChatResponse : KAIBase
@property (class, readonly, getter=companion) KAIChatResponseCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSString *role __attribute__((swift_name("role")));
- (instancetype)initWithRole:(NSString *)role content:(NSString *)content __attribute__((swift_name("init(role:content:)"))) __attribute__((objc_designated_initializer));
- (KAIChatResponse *)doCopyRole:(NSString *)role content:(NSString *)content __attribute__((swift_name("doCopy(role:content:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatResponse.Companion")))
@interface KAIChatResponseCompanion : KAIBase
@property (class, readonly, getter=shared) KAIChatResponseCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Choice")))
@interface KAIChoice : KAIBase
@property (class, readonly, getter=companion) KAIChoiceCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) KAIDelta * _Nullable delta __attribute__((swift_name("delta")));
@property (readonly) NSString * _Nullable finish_reason __attribute__((swift_name("finish_reason")));
@property (readonly) int32_t index __attribute__((swift_name("index")));
- (instancetype)initWithIndex:(int32_t)index delta:(KAIDelta * _Nullable)delta finish_reason:(NSString * _Nullable)finish_reason __attribute__((swift_name("init(index:delta:finish_reason:)"))) __attribute__((objc_designated_initializer));
- (KAIChoice *)doCopyIndex:(int32_t)index delta:(KAIDelta * _Nullable)delta finish_reason:(NSString * _Nullable)finish_reason __attribute__((swift_name("doCopy(index:delta:finish_reason:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Choice.Companion")))
@interface KAIChoiceCompanion : KAIBase
@property (class, readonly, getter=shared) KAIChoiceCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChoiceResponse")))
@interface KAIChoiceResponse : KAIBase
@property (class, readonly, getter=companion) KAIChoiceResponseCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSArray<KAIChoice *> *choices __attribute__((swift_name("choices")));
- (instancetype)initWithChoices:(NSArray<KAIChoice *> *)choices __attribute__((swift_name("init(choices:)"))) __attribute__((objc_designated_initializer));
- (KAIChoiceResponse *)doCopyChoices:(NSArray<KAIChoice *> *)choices __attribute__((swift_name("doCopy(choices:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChoiceResponse.Companion")))
@interface KAIChoiceResponseCompanion : KAIBase
@property (class, readonly, getter=shared) KAIChoiceResponseCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("ConversationRepository")))
@protocol KAIConversationRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createConversationPrompt:(KAIPrompt * _Nullable)prompt completionHandler:(void (^)(KAIConversation * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createConversation(prompt:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConversationRepositoryWeltGoImpl")))
@interface KAIConversationRepositoryWeltGoImpl : KAIBase <KAIConversationRepository>
- (instancetype)initWithWeltGoService:(KAIWeltGoService *)weltGoService __attribute__((swift_name("init(weltGoService:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createConversationPrompt:(KAIPrompt * _Nullable)prompt completionHandler:(void (^)(KAIConversation * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createConversation(prompt:completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConversationResponse")))
@interface KAIConversationResponse : KAIBase
@property (class, readonly, getter=companion) KAIConversationResponseCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *conversationId __attribute__((swift_name("conversationId")));
@property (readonly) NSString *createdAt __attribute__((swift_name("createdAt")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@property (readonly) BOOL isDeleted __attribute__((swift_name("isDeleted")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) NSString *updatedAt __attribute__((swift_name("updatedAt")));
@property (readonly) KAIUser *user __attribute__((swift_name("user")));
- (instancetype)initWithId:(int32_t)id createdAt:(NSString *)createdAt updatedAt:(NSString *)updatedAt conversationId:(NSString *)conversationId title:(NSString * _Nullable)title user:(KAIUser *)user isDeleted:(BOOL)isDeleted __attribute__((swift_name("init(id:createdAt:updatedAt:conversationId:title:user:isDeleted:)"))) __attribute__((objc_designated_initializer));
- (KAIConversationResponse *)doCopyId:(int32_t)id createdAt:(NSString *)createdAt updatedAt:(NSString *)updatedAt conversationId:(NSString *)conversationId title:(NSString * _Nullable)title user:(KAIUser *)user isDeleted:(BOOL)isDeleted __attribute__((swift_name("doCopy(id:createdAt:updatedAt:conversationId:title:user:isDeleted:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConversationResponse.Companion")))
@interface KAIConversationResponseCompanion : KAIBase
@property (class, readonly, getter=shared) KAIConversationResponseCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Delta")))
@interface KAIDelta : KAIBase
@property (class, readonly, getter=companion) KAIDeltaCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) KAIBoolean * _Nullable is_processing __attribute__((swift_name("is_processing")));
- (instancetype)initWithContent:(NSString *)content is_processing:(KAIBoolean * _Nullable)is_processing __attribute__((swift_name("init(content:is_processing:)"))) __attribute__((objc_designated_initializer));
- (KAIDelta *)doCopyContent:(NSString *)content is_processing:(KAIBoolean * _Nullable)is_processing __attribute__((swift_name("doCopy(content:is_processing:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Delta.Companion")))
@interface KAIDeltaCompanion : KAIBase
@property (class, readonly, getter=shared) KAIDeltaCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FeaturedPrompt")))
@interface KAIFeaturedPrompt : KAIBase
@property (class, readonly, getter=companion) KAIFeaturedPromptCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *assistantResponse __attribute__((swift_name("assistantResponse")));
@property (readonly) NSString *createdAt __attribute__((swift_name("createdAt")));
@property (readonly) NSString *experienceId __attribute__((swift_name("experienceId")));
@property (readonly) NSString *featuredPromptId __attribute__((swift_name("featuredPromptId")));
@property (readonly) BOOL hasSuggestions __attribute__((swift_name("hasSuggestions")));
@property (readonly) NSString *highCostModel __attribute__((swift_name("highCostModel")));
@property (readonly) NSString *image __attribute__((swift_name("image")));
@property (readonly) NSString *imageCredit __attribute__((swift_name("imageCredit")));
@property (readonly) NSString *imageUrl __attribute__((swift_name("imageUrl")));
@property (readonly) BOOL inlineSuggestions __attribute__((swift_name("inlineSuggestions")));
@property (readonly) BOOL isArchived __attribute__((swift_name("isArchived")));
@property (readonly) BOOL isDefaultFavorite __attribute__((swift_name("isDefaultFavorite")));
@property (readonly) BOOL isImageUploadEnabled __attribute__((swift_name("isImageUploadEnabled")));
@property (readonly) BOOL isPublic __attribute__((swift_name("isPublic")));
@property (readonly) NSString *label __attribute__((swift_name("label")));
@property (readonly) NSString * _Nullable lowCostModel __attribute__((swift_name("lowCostModel")));
@property (readonly) BOOL noAds __attribute__((swift_name("noAds")));
@property (readonly) int32_t ranking __attribute__((swift_name("ranking")));
@property (readonly) NSString *slug __attribute__((swift_name("slug")));
@property (readonly) NSString * _Nullable suggestedResponsesPrompt __attribute__((swift_name("suggestedResponsesPrompt")));
@property (readonly) float temperature __attribute__((swift_name("temperature")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@property (readonly) NSString *updatedAt __attribute__((swift_name("updatedAt")));
- (instancetype)initWithExperienceId:(NSString *)experienceId title:(NSString *)title imageUrl:(NSString *)imageUrl label:(NSString *)label image:(NSString *)image assistantResponse:(NSString *)assistantResponse ranking:(int32_t)ranking isPublic:(BOOL)isPublic isArchived:(BOOL)isArchived highCostModel:(NSString *)highCostModel lowCostModel:(NSString * _Nullable)lowCostModel inlineSuggestions:(BOOL)inlineSuggestions noAds:(BOOL)noAds hasSuggestions:(BOOL)hasSuggestions isImageUploadEnabled:(BOOL)isImageUploadEnabled isDefaultFavorite:(BOOL)isDefaultFavorite temperature:(float)temperature createdAt:(NSString *)createdAt updatedAt:(NSString *)updatedAt suggestedResponsesPrompt:(NSString * _Nullable)suggestedResponsesPrompt slug:(NSString *)slug imageCredit:(NSString *)imageCredit featuredPromptId:(NSString *)featuredPromptId __attribute__((swift_name("init(experienceId:title:imageUrl:label:image:assistantResponse:ranking:isPublic:isArchived:highCostModel:lowCostModel:inlineSuggestions:noAds:hasSuggestions:isImageUploadEnabled:isDefaultFavorite:temperature:createdAt:updatedAt:suggestedResponsesPrompt:slug:imageCredit:featuredPromptId:)"))) __attribute__((objc_designated_initializer));
- (KAIFeaturedPrompt *)doCopyExperienceId:(NSString *)experienceId title:(NSString *)title imageUrl:(NSString *)imageUrl label:(NSString *)label image:(NSString *)image assistantResponse:(NSString *)assistantResponse ranking:(int32_t)ranking isPublic:(BOOL)isPublic isArchived:(BOOL)isArchived highCostModel:(NSString *)highCostModel lowCostModel:(NSString * _Nullable)lowCostModel inlineSuggestions:(BOOL)inlineSuggestions noAds:(BOOL)noAds hasSuggestions:(BOOL)hasSuggestions isImageUploadEnabled:(BOOL)isImageUploadEnabled isDefaultFavorite:(BOOL)isDefaultFavorite temperature:(float)temperature createdAt:(NSString *)createdAt updatedAt:(NSString *)updatedAt suggestedResponsesPrompt:(NSString * _Nullable)suggestedResponsesPrompt slug:(NSString *)slug imageCredit:(NSString *)imageCredit featuredPromptId:(NSString *)featuredPromptId __attribute__((swift_name("doCopy(experienceId:title:imageUrl:label:image:assistantResponse:ranking:isPublic:isArchived:highCostModel:lowCostModel:inlineSuggestions:noAds:hasSuggestions:isImageUploadEnabled:isDefaultFavorite:temperature:createdAt:updatedAt:suggestedResponsesPrompt:slug:imageCredit:featuredPromptId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FeaturedPrompt.Companion")))
@interface KAIFeaturedPromptCompanion : KAIBase
@property (class, readonly, getter=shared) KAIFeaturedPromptCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FeaturedPromptsResponse")))
@interface KAIFeaturedPromptsResponse : KAIBase
@property (class, readonly, getter=companion) KAIFeaturedPromptsResponseCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) int32_t currentPage __attribute__((swift_name("currentPage")));
@property (readonly) NSArray<KAIFeaturedPrompt *> *data __attribute__((swift_name("data")));
@property (readonly) int32_t totalCount __attribute__((swift_name("totalCount")));
@property (readonly) int32_t totalPages __attribute__((swift_name("totalPages")));
- (instancetype)initWithData:(NSArray<KAIFeaturedPrompt *> *)data totalCount:(int32_t)totalCount totalPages:(int32_t)totalPages currentPage:(int32_t)currentPage __attribute__((swift_name("init(data:totalCount:totalPages:currentPage:)"))) __attribute__((objc_designated_initializer));
- (KAIFeaturedPromptsResponse *)doCopyData:(NSArray<KAIFeaturedPrompt *> *)data totalCount:(int32_t)totalCount totalPages:(int32_t)totalPages currentPage:(int32_t)currentPage __attribute__((swift_name("doCopy(data:totalCount:totalPages:currentPage:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FeaturedPromptsResponse.Companion")))
@interface KAIFeaturedPromptsResponseCompanion : KAIBase
@property (class, readonly, getter=shared) KAIFeaturedPromptsResponseCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("PromptRepository")))
@protocol KAIPromptRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPromptId:(NSString *)id completionHandler:(void (^)(KAIPrompt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPrompt(id:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPromptsWithCompletionHandler:(void (^)(NSArray<KAIPrompt *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPrompts(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PromptRepositoryWeltGoImpl")))
@interface KAIPromptRepositoryWeltGoImpl : KAIBase <KAIPromptRepository>
- (instancetype)initWithWeltGoService:(KAIWeltGoService *)weltGoService __attribute__((swift_name("init(weltGoService:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPromptId:(NSString *)id completionHandler:(void (^)(KAIPrompt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPrompt(id:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPromptsWithCompletionHandler:(void (^)(NSArray<KAIPrompt *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPrompts(completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServerSentEventDataResponse")))
@interface KAIServerSentEventDataResponse : KAIBase
@property (class, readonly, getter=companion) KAIServerSentEventDataResponseCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSArray<KAIChoice *> *choices __attribute__((swift_name("choices")));
@property (readonly) KAIInt * _Nullable created __attribute__((swift_name("created")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable model __attribute__((swift_name("model")));
@property (readonly) NSString * _Nullable object __attribute__((swift_name("object")));
@property (readonly) NSString * _Nullable system_fingerprint __attribute__((swift_name("system_fingerprint")));
- (instancetype)initWithId:(NSString * _Nullable)id object:(NSString * _Nullable)object created:(KAIInt * _Nullable)created model:(NSString * _Nullable)model system_fingerprint:(NSString * _Nullable)system_fingerprint choices:(NSArray<KAIChoice *> *)choices __attribute__((swift_name("init(id:object:created:model:system_fingerprint:choices:)"))) __attribute__((objc_designated_initializer));
- (KAIServerSentEventDataResponse *)doCopyId:(NSString * _Nullable)id object:(NSString * _Nullable)object created:(KAIInt * _Nullable)created model:(NSString * _Nullable)model system_fingerprint:(NSString * _Nullable)system_fingerprint choices:(NSArray<KAIChoice *> *)choices __attribute__((swift_name("doCopy(id:object:created:model:system_fingerprint:choices:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServerSentEventDataResponse.Companion")))
@interface KAIServerSentEventDataResponseCompanion : KAIBase
@property (class, readonly, getter=shared) KAIServerSentEventDataResponseCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("SuggestionRepository")))
@protocol KAISuggestionRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSuggestionConversation:(KAIConversation *)conversation completionHandler:(void (^)(NSArray<KAISuggestion *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSuggestion(conversation:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SuggestionRepositoryWeltGoImpl")))
@interface KAISuggestionRepositoryWeltGoImpl : KAIBase <KAISuggestionRepository>
- (instancetype)initWithWeltGoService:(KAIWeltGoService *)weltGoService __attribute__((swift_name("init(weltGoService:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSuggestionConversation:(KAIConversation *)conversation completionHandler:(void (^)(NSArray<KAISuggestion *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSuggestion(conversation:completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SuggestionResponse")))
@interface KAISuggestionResponse : KAIBase
@property (class, readonly, getter=companion) KAISuggestionResponseCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *source __attribute__((swift_name("source")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
- (instancetype)initWithText:(NSString *)text source:(NSString *)source __attribute__((swift_name("init(text:source:)"))) __attribute__((objc_designated_initializer));
- (KAISuggestionResponse *)doCopyText:(NSString *)text source:(NSString *)source __attribute__((swift_name("doCopy(text:source:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SuggestionResponse.Companion")))
@interface KAISuggestionResponseCompanion : KAIBase
@property (class, readonly, getter=shared) KAISuggestionResponseCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User")))
@interface KAIUser : KAIBase
@property (class, readonly, getter=companion) KAIUserCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *auth0UserId __attribute__((swift_name("auth0UserId")));
@property (readonly) NSString *createdAt __attribute__((swift_name("createdAt")));
@property (readonly) NSString *updatedAt __attribute__((swift_name("updatedAt")));
@property (readonly) NSString *uuid __attribute__((swift_name("uuid")));
- (instancetype)initWithUuid:(NSString *)uuid auth0UserId:(NSString *)auth0UserId createdAt:(NSString *)createdAt updatedAt:(NSString *)updatedAt __attribute__((swift_name("init(uuid:auth0UserId:createdAt:updatedAt:)"))) __attribute__((objc_designated_initializer));
- (KAIUser *)doCopyUuid:(NSString *)uuid auth0UserId:(NSString *)auth0UserId createdAt:(NSString *)createdAt updatedAt:(NSString *)updatedAt __attribute__((swift_name("doCopy(uuid:auth0UserId:createdAt:updatedAt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User.Companion")))
@interface KAIUserCompanion : KAIBase
@property (class, readonly, getter=shared) KAIUserCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WeltGoService")))
@interface KAIWeltGoService : KAIBase
- (instancetype)initWithAsid:(NSString *)asid __attribute__((swift_name("init(asid:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)chatChatRequest:(KAIChatRequest *)chatRequest uuid:(NSString *)uuid conversationId:(NSString *)conversationId completionHandler:(void (^)(KAIChatResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("chat(chatRequest:uuid:conversationId:completionHandler:)")));
- (id<KAIKotlinx_coroutines_coreFlow>)chatFlowChatRequest:(KAIChatRequest *)chatRequest uuid:(NSString *)uuid conversationId:(NSString *)conversationId __attribute__((swift_name("chatFlow(chatRequest:uuid:conversationId:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createConversationUuid:(NSString *)uuid completionHandler:(void (^)(KAIConversationResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createConversation(uuid:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFeaturedPromptId:(NSString *)id completionHandler:(void (^)(KAIFeaturedPrompt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getFeaturedPrompt(id:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFeaturedPromptsPage:(int32_t)page limit:(int32_t)limit completionHandler:(void (^)(KAIFeaturedPromptsResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getFeaturedPrompts(page:limit:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)seedConversationId:(NSString *)conversationId experienceId:(NSString * _Nullable)experienceId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("seed(conversationId:experienceId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)suggestUserId:(NSString *)userId conversationId:(NSString *)conversationId experienceId:(NSString * _Nullable)experienceId completionHandler:(void (^)(NSArray<KAISuggestionResponse *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("suggest(userId:conversationId:experienceId:completionHandler:)")));
@end

__attribute__((swift_name("BaseUseCase")))
@protocol KAIBaseUseCase
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((swift_name("BaseUseCaseFlow")))
@protocol KAIBaseUseCaseFlow
@required
- (id<KAIKotlinx_coroutines_coreFlow>)invokeParams:(id _Nullable)params __attribute__((swift_name("invoke(params:)")));
@end

__attribute__((swift_name("BaseUseCaseWithParams")))
@protocol KAIBaseUseCaseWithParams
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeParams:(id _Nullable)params completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(params:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Answer")))
@interface KAIAnswer : KAIBase
@property (readonly) BOOL completed __attribute__((swift_name("completed")));
@property (readonly) NSString *role __attribute__((swift_name("role")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
- (instancetype)initWithText:(NSString *)text role:(NSString *)role completed:(BOOL)completed __attribute__((swift_name("init(text:role:completed:)"))) __attribute__((objc_designated_initializer));
- (KAIAnswer *)doCopyText:(NSString *)text role:(NSString *)role completed:(BOOL)completed __attribute__((swift_name("doCopy(text:role:completed:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Chat")))
@interface KAIChat : KAIBase
@property (readonly) KAIAnswer *answer __attribute__((swift_name("answer")));
@property (readonly) KAIQuestion *question __attribute__((swift_name("question")));
- (instancetype)initWithQuestion:(KAIQuestion *)question answer:(KAIAnswer *)answer __attribute__((swift_name("init(question:answer:)"))) __attribute__((objc_designated_initializer));
- (KAIChat *)doCopyQuestion:(KAIQuestion *)question answer:(KAIAnswer *)answer __attribute__((swift_name("doCopy(question:answer:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatFlowUseCase")))
@interface KAIChatFlowUseCase : KAIBase <KAIBaseUseCaseFlow>
- (instancetype)initWithChatRepository:(id<KAIChatRepository>)chatRepository __attribute__((swift_name("init(chatRepository:)"))) __attribute__((objc_designated_initializer));
- (id<KAIKotlinx_coroutines_coreFlow>)invokeParams:(KAIQuestion *)params __attribute__((swift_name("invoke(params:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatUseCase")))
@interface KAIChatUseCase : KAIBase <KAIBaseUseCaseWithParams>
- (instancetype)initWithChatRepository:(id<KAIChatRepository>)chatRepository __attribute__((swift_name("init(chatRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeParams:(KAIQuestion *)params completionHandler:(void (^)(KAIAnswer * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(params:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Question")))
@interface KAIQuestion : KAIBase
@property (readonly) KAIConversation *conversation __attribute__((swift_name("conversation")));
@property (readonly) KAISource *source __attribute__((swift_name("source")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
- (instancetype)initWithConversation:(KAIConversation *)conversation text:(NSString *)text source:(KAISource *)source __attribute__((swift_name("init(conversation:text:source:)"))) __attribute__((objc_designated_initializer));
- (KAIQuestion *)doCopyConversation:(KAIConversation *)conversation text:(NSString *)text source:(KAISource *)source __attribute__((swift_name("doCopy(conversation:text:source:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol KAIKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface KAIKotlinEnum<E> : KAIBase <KAIKotlinComparable>
@property (class, readonly, getter=companion) KAIKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Source")))
@interface KAISource : KAIKotlinEnum<KAISource *>
@property (class, readonly) KAISource *custom __attribute__((swift_name("custom")));
@property (class, readonly) KAISource *suggested __attribute__((swift_name("suggested")));
@property (class, readonly) NSArray<KAISource *> *entries __attribute__((swift_name("entries")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (KAIKotlinArray<KAISource *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Conversation")))
@interface KAIConversation : KAIBase
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) KAIPrompt * _Nullable prompt __attribute__((swift_name("prompt")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) NSString *uuid __attribute__((swift_name("uuid")));
- (instancetype)initWithUuid:(NSString *)uuid id:(NSString *)id title:(NSString * _Nullable)title prompt:(KAIPrompt * _Nullable)prompt __attribute__((swift_name("init(uuid:id:title:prompt:)"))) __attribute__((objc_designated_initializer));
- (KAIConversation *)doCopyUuid:(NSString *)uuid id:(NSString *)id title:(NSString * _Nullable)title prompt:(KAIPrompt * _Nullable)prompt __attribute__((swift_name("doCopy(uuid:id:title:prompt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateConversationUseCase")))
@interface KAICreateConversationUseCase : KAIBase <KAIBaseUseCaseWithParams>
- (instancetype)initWithConversationRepository:(id<KAIConversationRepository>)conversationRepository __attribute__((swift_name("init(conversationRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeParams:(KAIPrompt * _Nullable)params completionHandler:(void (^)(KAIConversation * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(params:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetPromptUseCase")))
@interface KAIGetPromptUseCase : KAIBase <KAIBaseUseCaseWithParams>
- (instancetype)initWithPromptRepository:(id<KAIPromptRepository>)promptRepository __attribute__((swift_name("init(promptRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeParams:(NSString *)params completionHandler:(void (^)(KAIPrompt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(params:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetPromptsUseCase")))
@interface KAIGetPromptsUseCase : KAIBase <KAIBaseUseCase>
- (instancetype)initWithPromptRepository:(id<KAIPromptRepository>)promptRepository __attribute__((swift_name("init(promptRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(NSArray<KAIPrompt *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Prompt")))
@interface KAIPrompt : KAIBase
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *slug __attribute__((swift_name("slug")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
- (instancetype)initWithId:(NSString *)id slug:(NSString *)slug title:(NSString *)title description:(NSString *)description __attribute__((swift_name("init(id:slug:title:description:)"))) __attribute__((objc_designated_initializer));
- (KAIPrompt *)doCopyId:(NSString *)id slug:(NSString *)slug title:(NSString *)title description:(NSString *)description __attribute__((swift_name("doCopy(id:slug:title:description:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetSuggestionsUseCase")))
@interface KAIGetSuggestionsUseCase : KAIBase <KAIBaseUseCaseWithParams>
- (instancetype)initWithSuggestionRepository:(id<KAISuggestionRepository>)suggestionRepository __attribute__((swift_name("init(suggestionRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeParams:(KAIConversation *)params completionHandler:(void (^)(NSArray<KAISuggestion *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(params:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Suggestion")))
@interface KAISuggestion : KAIBase
@property (readonly) NSString *source __attribute__((swift_name("source")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
- (instancetype)initWithText:(NSString *)text source:(NSString *)source __attribute__((swift_name("init(text:source:)"))) __attribute__((objc_designated_initializer));
- (KAISuggestion *)doCopyText:(NSString *)text source:(NSString *)source __attribute__((swift_name("doCopy(text:source:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Platform_iosKt")))
@interface KAIPlatform_iosKt : KAIBase
+ (NSString *)getUUID __attribute__((swift_name("getUUID()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("__SkieSuspendWrappersKt")))
@interface KAI__SkieSuspendWrappersKt : KAIBase
+ (void)Skie_Suspend__0__hasNextDispatchReceiver:(KAISkieColdFlowIterator<id> *)dispatchReceiver suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__0__hasNext(dispatchReceiver:suspendHandler:)")));
+ (void)Skie_Suspend__10__chatDispatchReceiver:(KAIWeltGoService *)dispatchReceiver chatRequest:(KAIChatRequest *)chatRequest uuid:(NSString *)uuid conversationId:(NSString *)conversationId suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__10__chat(dispatchReceiver:chatRequest:uuid:conversationId:suspendHandler:)")));
+ (void)Skie_Suspend__11__createConversationDispatchReceiver:(KAIWeltGoService *)dispatchReceiver uuid:(NSString *)uuid suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__11__createConversation(dispatchReceiver:uuid:suspendHandler:)")));
+ (void)Skie_Suspend__12__getFeaturedPromptDispatchReceiver:(KAIWeltGoService *)dispatchReceiver id:(NSString *)id suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__12__getFeaturedPrompt(dispatchReceiver:id:suspendHandler:)")));
+ (void)Skie_Suspend__13__getFeaturedPromptsDispatchReceiver:(KAIWeltGoService *)dispatchReceiver page:(int32_t)page limit:(int32_t)limit suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__13__getFeaturedPrompts(dispatchReceiver:page:limit:suspendHandler:)")));
+ (void)Skie_Suspend__14__seedDispatchReceiver:(KAIWeltGoService *)dispatchReceiver conversationId:(NSString *)conversationId experienceId:(NSString * _Nullable)experienceId suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__14__seed(dispatchReceiver:conversationId:experienceId:suspendHandler:)")));
+ (void)Skie_Suspend__15__suggestDispatchReceiver:(KAIWeltGoService *)dispatchReceiver userId:(NSString *)userId conversationId:(NSString *)conversationId experienceId:(NSString * _Nullable)experienceId suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__15__suggest(dispatchReceiver:userId:conversationId:experienceId:suspendHandler:)")));
+ (void)Skie_Suspend__1__collectDispatchReceiver:(id<KAIKotlinx_coroutines_coreFlow>)dispatchReceiver collector:(id<KAIKotlinx_coroutines_coreFlowCollector>)collector suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__1__collect(dispatchReceiver:collector:suspendHandler:)")));
+ (void)Skie_Suspend__2__emitDispatchReceiver:(id<KAIKotlinx_coroutines_coreFlowCollector>)dispatchReceiver value:(id _Nullable)value suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__2__emit(dispatchReceiver:value:suspendHandler:)")));
+ (void)Skie_Suspend__3__invokeDispatchReceiver:(id<KAIBaseUseCase>)dispatchReceiver suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__3__invoke(dispatchReceiver:suspendHandler:)")));
+ (void)Skie_Suspend__4__invokeDispatchReceiver:(id<KAIBaseUseCaseWithParams>)dispatchReceiver params:(id _Nullable)params suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__4__invoke(dispatchReceiver:params:suspendHandler:)")));
+ (void)Skie_Suspend__5__chatDispatchReceiver:(id<KAIChatRepository>)dispatchReceiver question:(KAIQuestion *)question suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__5__chat(dispatchReceiver:question:suspendHandler:)")));
+ (void)Skie_Suspend__6__createConversationDispatchReceiver:(id<KAIConversationRepository>)dispatchReceiver prompt:(KAIPrompt * _Nullable)prompt suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__6__createConversation(dispatchReceiver:prompt:suspendHandler:)")));
+ (void)Skie_Suspend__7__getPromptDispatchReceiver:(id<KAIPromptRepository>)dispatchReceiver id:(NSString *)id suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__7__getPrompt(dispatchReceiver:id:suspendHandler:)")));
+ (void)Skie_Suspend__8__getPromptsDispatchReceiver:(id<KAIPromptRepository>)dispatchReceiver suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__8__getPrompts(dispatchReceiver:suspendHandler:)")));
+ (void)Skie_Suspend__9__getSuggestionDispatchReceiver:(id<KAISuggestionRepository>)dispatchReceiver conversation:(KAIConversation *)conversation suspendHandler:(KAISkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__9__getSuggestion(dispatchReceiver:conversation:suspendHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("__SkieTypeExportsKt")))
@interface KAI__SkieTypeExportsKt : KAIBase
+ (void)skieTypeExports_0P0:(KAIKtor_sseServerSentEvent *)p0 p1:(KAIKotlinx_serialization_corePolymorphicKind *)p1 p2:(KAIKotlinx_serialization_corePolymorphicKindOPEN *)p2 p3:(KAIKotlinx_serialization_corePolymorphicKindSEALED *)p3 p4:(KAIKotlinx_serialization_corePrimitiveKind *)p4 p5:(KAIKotlinx_serialization_corePrimitiveKindBOOLEAN *)p5 p6:(KAIKotlinx_serialization_corePrimitiveKindBYTE *)p6 p7:(KAIKotlinx_serialization_corePrimitiveKindCHAR *)p7 p8:(KAIKotlinx_serialization_corePrimitiveKindDOUBLE *)p8 p9:(KAIKotlinx_serialization_corePrimitiveKindFLOAT *)p9 p10:(KAIKotlinx_serialization_corePrimitiveKindINT *)p10 p11:(KAIKotlinx_serialization_corePrimitiveKindLONG *)p11 p12:(KAIKotlinx_serialization_corePrimitiveKindSHORT *)p12 p13:(KAIKotlinx_serialization_corePrimitiveKindSTRING *)p13 p14:(KAIKotlinx_serialization_coreSerialKindCONTEXTUAL *)p14 p15:(KAIKotlinx_serialization_coreSerialKindENUM *)p15 p16:(KAIKotlinx_serialization_coreStructureKind *)p16 p17:(KAIKotlinx_serialization_coreStructureKindCLASS *)p17 p18:(KAIKotlinx_serialization_coreStructureKindLIST *)p18 p19:(KAIKotlinx_serialization_coreStructureKindMAP *)p19 p20:(KAIKotlinx_serialization_coreStructureKindOBJECT *)p20 __attribute__((swift_name("skieTypeExports_0(p0:p1:p2:p3:p4:p5:p6:p7:p8:p9:p10:p11:p12:p13:p14:p15:p16:p17:p18:p19:p20:)")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface KAIKotlinThrowable : KAIBase
@property (readonly) KAIKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (KAIKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface KAIKotlinException : KAIKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface KAIKotlinRuntimeException : KAIKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface KAIKotlinIllegalStateException : KAIKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface KAIKotlinCancellationException : KAIKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KAIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol KAIKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol KAIKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<KAIKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<KAIKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol KAIKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<KAIKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<KAIKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol KAIKotlinx_serialization_coreKSerializer <KAIKotlinx_serialization_coreSerializationStrategy, KAIKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface KAIKotlinEnumCompanion : KAIBase
@property (class, readonly, getter=shared) KAIKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface KAIKotlinArray<T> : KAIBase
@property (readonly) int32_t size __attribute__((swift_name("size")));
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(KAIInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<KAIKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_sseServerSentEvent")))
@interface KAIKtor_sseServerSentEvent : KAIBase
@property (readonly) NSString * _Nullable comments __attribute__((swift_name("comments")));
@property (readonly) NSString * _Nullable data __attribute__((swift_name("data")));
@property (readonly) NSString * _Nullable event __attribute__((swift_name("event")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) KAILong * _Nullable retry __attribute__((swift_name("retry")));
- (instancetype)initWithData:(NSString * _Nullable)data event:(NSString * _Nullable)event id:(NSString * _Nullable)id retry:(KAILong * _Nullable)retry comments:(NSString * _Nullable)comments __attribute__((swift_name("init(data:event:id:retry:comments:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface KAIKotlinx_serialization_coreSerialKind : KAIBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_corePolymorphicKind")))
@interface KAIKotlinx_serialization_corePolymorphicKind : KAIKotlinx_serialization_coreSerialKind
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePolymorphicKind.OPEN")))
@interface KAIKotlinx_serialization_corePolymorphicKindOPEN : KAIKotlinx_serialization_corePolymorphicKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePolymorphicKindOPEN *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)oPEN __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePolymorphicKind.SEALED")))
@interface KAIKotlinx_serialization_corePolymorphicKindSEALED : KAIKotlinx_serialization_corePolymorphicKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePolymorphicKindSEALED *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sEALED __attribute__((swift_name("init()")));
@end

__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind")))
@interface KAIKotlinx_serialization_corePrimitiveKind : KAIKotlinx_serialization_coreSerialKind
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.BOOLEAN")))
@interface KAIKotlinx_serialization_corePrimitiveKindBOOLEAN : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindBOOLEAN *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)bOOLEAN __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.BYTE")))
@interface KAIKotlinx_serialization_corePrimitiveKindBYTE : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindBYTE *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)bYTE __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.CHAR")))
@interface KAIKotlinx_serialization_corePrimitiveKindCHAR : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindCHAR *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)cHAR __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.DOUBLE")))
@interface KAIKotlinx_serialization_corePrimitiveKindDOUBLE : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindDOUBLE *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)dOUBLE __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.FLOAT")))
@interface KAIKotlinx_serialization_corePrimitiveKindFLOAT : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindFLOAT *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)fLOAT __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.INT")))
@interface KAIKotlinx_serialization_corePrimitiveKindINT : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindINT *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)iNT __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.LONG")))
@interface KAIKotlinx_serialization_corePrimitiveKindLONG : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindLONG *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)lONG __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.SHORT")))
@interface KAIKotlinx_serialization_corePrimitiveKindSHORT : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindSHORT *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sHORT __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_corePrimitiveKind.STRING")))
@interface KAIKotlinx_serialization_corePrimitiveKindSTRING : KAIKotlinx_serialization_corePrimitiveKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_corePrimitiveKindSTRING *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sTRING __attribute__((swift_name("init()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind.CONTEXTUAL")))
@interface KAIKotlinx_serialization_coreSerialKindCONTEXTUAL : KAIKotlinx_serialization_coreSerialKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_coreSerialKindCONTEXTUAL *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)cONTEXTUAL __attribute__((swift_name("init()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind.ENUM")))
@interface KAIKotlinx_serialization_coreSerialKindENUM : KAIKotlinx_serialization_coreSerialKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_coreSerialKindENUM *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)eNUM __attribute__((swift_name("init()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreStructureKind")))
@interface KAIKotlinx_serialization_coreStructureKind : KAIKotlinx_serialization_coreSerialKind
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_coreStructureKind.CLASS")))
@interface KAIKotlinx_serialization_coreStructureKindCLASS : KAIKotlinx_serialization_coreStructureKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_coreStructureKindCLASS *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)cLASS __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_coreStructureKind.LIST")))
@interface KAIKotlinx_serialization_coreStructureKindLIST : KAIKotlinx_serialization_coreStructureKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_coreStructureKindLIST *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)lIST __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_coreStructureKind.MAP")))
@interface KAIKotlinx_serialization_coreStructureKindMAP : KAIKotlinx_serialization_coreStructureKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_coreStructureKindMAP *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mAP __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_coreStructureKind.OBJECT")))
@interface KAIKotlinx_serialization_coreStructureKindOBJECT : KAIKotlinx_serialization_coreStructureKind
@property (class, readonly, getter=shared) KAIKotlinx_serialization_coreStructureKindOBJECT *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)oBJECT __attribute__((swift_name("init()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol KAIKotlinx_serialization_coreEncoder
@required
- (id<KAIKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<KAIKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<KAIKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<KAIKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<KAIKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) KAIKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol KAIKotlinx_serialization_coreSerialDescriptor
@required

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSArray<id<KAIKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<KAIKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSArray<id<KAIKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) KAIKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol KAIKotlinx_serialization_coreDecoder
@required
- (id<KAIKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<KAIKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (KAIKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<KAIKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<KAIKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) KAIKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol KAIKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol KAIKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<KAIKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<KAIKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<KAIKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) KAIKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface KAIKotlinx_serialization_coreSerializersModule : KAIBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<KAIKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<KAIKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<KAIKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<KAIKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<KAIKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<KAIKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<KAIKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<KAIKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol KAIKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol KAIKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<KAIKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<KAIKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<KAIKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<KAIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) KAIKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface KAIKotlinNothing : KAIBase
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol KAIKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<KAIKotlinKClass>)kClass provider:(id<KAIKotlinx_serialization_coreKSerializer> (^)(NSArray<id<KAIKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<KAIKotlinKClass>)kClass serializer:(id<KAIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<KAIKotlinKClass>)baseClass actualClass:(id<KAIKotlinKClass>)actualClass actualSerializer:(id<KAIKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<KAIKotlinKClass>)baseClass defaultDeserializerProvider:(id<KAIKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<KAIKotlinKClass>)baseClass defaultDeserializerProvider:(id<KAIKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<KAIKotlinKClass>)baseClass defaultSerializerProvider:(id<KAIKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol KAIKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol KAIKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol KAIKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol KAIKotlinKClass <KAIKotlinKDeclarationContainer, KAIKotlinKAnnotatedElement, KAIKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
